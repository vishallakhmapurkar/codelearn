package com.assetcontrol.loggenerator.main;

import org.apache.log4j.Logger;

public class LogGenerator {

	public static void main(String[] args) throws InterruptedException {
		int NUMBER = 10;
		Logger logger =Logger.getLogger(LogGenerator.class);
		int i=1;
		while(true) {
			logger.info("Application started");
			logger.info("Checking all webservice conection ");
			logger.info("Checking all database conection ");
			for(i=1;i<NUMBER;i++) {
				logger.info("Pprocessing block:"+"["+i+"]");
				if(i==5) {
					logger.warn(" 50 %  block  processed");
				}
				if(i==9) {
					logger.error("Error while processing block number "+"["+i+"]");
					logger.info(" Application ended");
					logger.info("Restarting application");
					i=1;
					break;
				}
				Thread.sleep(3000);
				
			}
		}

	}

}
