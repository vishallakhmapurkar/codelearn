package com.assetcontrol.logmonitor.model;

import java.util.Vector;

public class LogData {
    public int id;
    public Vector<Log> buffer;
}
