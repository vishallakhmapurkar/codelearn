package com.assetcontrol.logmonitor.domain;

import com.assetcontrol.logmonitor.model.Log;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

public class LogUtil {
	private static final String pattern = "\\r?\\n";
	private static final AtomicInteger  infoCounter = new AtomicInteger(0);
	private static final AtomicInteger  warnCounter = new AtomicInteger(0);
	private static final AtomicInteger  errorCounter = new AtomicInteger(0);
    public static Map<String,Integer> dataCounterMap = new ConcurrentHashMap<>();

    public static void separateLogs(List<String> result, String data, int startPosition) {
    	String lines[] = data.split(pattern);
    	result.addAll(Arrays.asList(lines));
     
    }

    public static Log parseLog(String data) {
        LogType type = detectType(data);
        String[] detected;
        detected = data.split(type.name());
        if (type != LogType.UNDEFINED && detected.length > 1) {
        	saveLogCounter(type);;
            return new Log(detected[0].trim(), type, detected[1].trim());
        }

        return new Log(LogType.UNDEFINED, data);
    }

    public static LogType detectType(String data) {
        Map<LogType, Integer> positionMap = new HashMap<>();
        Stream.of(LogType.values()).forEach(lt -> positionMap.put(lt, data.indexOf(lt.name())));
        return positionMap
                .entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue())
                .filter(l -> l.getValue() > 0)
                .findFirst()
                .map(Map.Entry::getKey)
                .orElse(LogType.UNDEFINED);
    }
    public static void saveLogCounter(LogType type) {
    	switch (type.name())
    	{   	
    	    case "INFO":{
    	    	dataCounterMap.put(type.name(), infoCounter.incrementAndGet());
    	    }case "WARN":{
    	    	dataCounterMap.put(type.name(), warnCounter.incrementAndGet());
    	    }case "ERROR":{
    	    	dataCounterMap.put(type.name(), errorCounter.incrementAndGet());
    	    }
    			
    	}
    	
    	
    }
}
