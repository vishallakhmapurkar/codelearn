package com.assetcontrol.logmonitor.domain;

import java.text.SimpleDateFormat;

public class Constants {
    public static final SimpleDateFormat DATE_FORMAT_TIME = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss.SSS");
}
