package com.assetcontrol.logmonitor.model;

import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.assetcontrol.logmonitor.domain.DateUtil;
import com.assetcontrol.logmonitor.domain.LogType;

public class LogCounts {
	   private String infoCounts;
	   private String warnCounts;
	   private String errorCounts;
	    public LogCounts() {
	    }
	   
	    public LogCounts(Map<String,Integer> dataCounterMap ) {
	        this.infoCounts = LogType.INFO.name()+"#"+dataCounterMap.get(LogType.INFO.name());
	        this.warnCounts = LogType.WARN.name()+"#"+dataCounterMap.get(LogType.WARN.name());;
	        this.errorCounts = LogType.ERROR.name()+"#"+dataCounterMap.get(LogType.ERROR.name());;
	       
	    }

		public String getInfoCounts() {
			return infoCounts;
		}

		

		public String getWarnCounts() {
			return warnCounts;
		}

	
		public String getErrorCounts() {
			return errorCounts;
		}

		

		@Override
		public int hashCode() {
			 return new HashCodeBuilder()
		                .append(this.getInfoCounts())
		                .append(this.getWarnCounts())
		                .append(this.getErrorCounts())
		                .toHashCode();
		}

		  @Override
		    public boolean equals(Object o) {
		        if (o instanceof LogCounts) {
		        	LogCounts logCounts = (LogCounts)o;
		            return new EqualsBuilder()
		                    .append(this.getInfoCounts(),logCounts.getInfoCounts())
		                    .append(this.getWarnCounts(),logCounts.getWarnCounts())
		                    .append(this.getErrorCounts(),logCounts.getErrorCounts())
		                    .isEquals();
		        }

		        return false;
		    }

		@Override
		public String toString() {
			return "infoCounts=" + infoCounts + ", warnCounts=" + warnCounts + ", errorCounts=" + errorCounts
					;
		}
		
	    
	    
}
