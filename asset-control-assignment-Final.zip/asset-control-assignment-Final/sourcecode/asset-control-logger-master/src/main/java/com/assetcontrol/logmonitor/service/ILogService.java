package com.assetcontrol.logmonitor.service;

import com.assetcontrol.logmonitor.model.Log;
import com.assetcontrol.logmonitor.model.LogConnector;
import com.assetcontrol.logmonitor.model.LogCounts;
import com.assetcontrol.logmonitor.model.LogsRequest;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public interface ILogService {

    void notifyLastLogsPeriod(LogsRequest request);
    void storeLog(List<Log> logs,final Integer dataId);
    void storeLog(Log log,final Integer dataId) ;
    void setWatchData(ConcurrentHashMap<Integer, LogConnector> watchData);
    List<LogConnector> getWatchData();
    LogCounts  getLogCounts();
}
