package com.assetcontrol.logmonitor.controller;

import com.assetcontrol.logmonitor.model.Log;
import com.assetcontrol.logmonitor.model.LogConnector;
import com.assetcontrol.logmonitor.model.LogCounts;
import com.assetcontrol.logmonitor.model.LogsRequest;
import com.assetcontrol.logmonitor.service.ILogService;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Map;

@Controller
public class LogController {

    private ILogService logService;

    public LogController(ILogService logService) {
        this.logService = logService;
    }

    @MessageMapping("/last-logs")
    public void lastLogs(LogsRequest request) throws Exception {
        logService.notifyLastLogsPeriod(request);
    }

    @MessageMapping("/available-logs")
    @SendTo("/topic/available-logs")
    public List<LogConnector> logMap() {
        return logService.getWatchData();
    }

    @MessageMapping("/new-log")
    public void newLog(Log log) throws Exception {
        logService.storeLog(log, log.getId());
    }
    @RequestMapping("/logCounts")
    public ResponseEntity<LogCounts> logCounts() {
    	return new ResponseEntity<LogCounts>(logService.getLogCounts(), HttpStatus.OK);
        
    }
}
