package com.assetcontrol.logmonitor.service;

import com.assetcontrol.logmonitor.model.Log;
import com.assetcontrol.logmonitor.model.LogCounts;

import org.springframework.context.ApplicationListener;
import org.springframework.messaging.simp.broker.BrokerAvailabilityEvent;
import java.util.List;

public interface INotificationService extends ApplicationListener<BrokerAvailabilityEvent> {

    void logNotification(Log log);
    void lastLogsNotification(List<Log> logs, String user);
}
