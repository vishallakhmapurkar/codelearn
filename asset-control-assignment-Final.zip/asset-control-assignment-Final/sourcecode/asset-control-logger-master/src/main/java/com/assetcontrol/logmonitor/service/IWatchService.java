package com.assetcontrol.logmonitor.service;

public interface IWatchService {
    void check();
}
