import React, { Component } from 'react';
import './App.css';
import Content from '../../containers/Content';
import LogCounts from '../../logcounter/LogCounts';
class App extends Component {
  render() {
    return (
     
    		<div>
            <header><div className="headerText"><h3>Welcome to Asset-Control Log Monitoring Application</h3><div className="controlpanel"></div></div>
            <LogCounts />
            </header>
            
            <Content />
            <footer></footer>
             </div>
     
    );
  }
}

export default App;
