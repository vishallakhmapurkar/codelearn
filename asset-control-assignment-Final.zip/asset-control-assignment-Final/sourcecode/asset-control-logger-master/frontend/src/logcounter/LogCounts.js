import React, { Component } from 'react';
import axios from 'axios';
import '../components/log/Logs.css';
class LogCounts extends Component {
	
	constructor(props) {
	    super(props);

	    this.state = {
	      loadcounts: []
	    };
	  }

	  componentDidMount() {
	    axios.get('http://localhost:7777/logCounts')
	      .then(res => {
	        const loadcounts = res.data.data;
	        this.setState({ loadcounts });
	      });
	  }

	  render() {
	    return (
	      <div>
	        <ul>
	          {this.state.loadcounts.map(loadcounts =>
	            <h3>{loadcounts.infoCounts}</h3>
	          )}
	        </ul>
	      </div>
	    );
	  }
	}



export default LogCounts;

